10 sample crate photos (1024x1024, from our validation set) where the models find the defects.
  images/                 the photos - use these to try the package (CRATE-DETECTOR-23NOV)
  drawn_single/           MODE "single" output drawn:   RED = model box (class + score), GREEN = labelled defect
  drawn_bigdefect/        MODE "bigdefect" output drawn (same colours)
  results_single.jsonl    exact output of det.predict() for each photo, MODE "single"
  results_bigdefect.jsonl same for MODE "bigdefect"
  labels_ground_truth.json the labelled defects for each photo

Try it:
  python CRATE-DETECTOR-23NOV/run_folder.py CRATE-DETECTOR-23NOV CRATE-SAMPLE-IMAGES-10/images out.jsonl --mode single --draw drawn/
  -> should match results_single.jsonl (on a GPU).
Classes covered: Crack, Scratch, Broken edge, Hole, Water damage.
